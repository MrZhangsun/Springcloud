package com.imooc.user.constant;

/**
 * Created by 廖师兄
 * 2018-03-04 23:37
 */
public interface RedisConstant {

	String TOKEN_TEMPLATE = "token_%s";

}
